package com.example.lesso4task3kotlin

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.lesso4task3kotlin.Model.User
import java.lang.String

class DetailActivity: AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val textView = TextView(this)
        textView.textSize = 26f
        textView.setPadding(16, 16, 16, 16)

        val arguments = intent.extras

        val user: User?

        if (arguments != null) {
            user = arguments.getParcelable(User::class.java.getSimpleName())
            if (user != null) {
                textView.text = """
                        Name: ${user.getName().toString()}
                        Age:${String.valueOf(user.getAge())}
                        """.trimIndent()
            }
        }
        setContentView(textView)
    }

}